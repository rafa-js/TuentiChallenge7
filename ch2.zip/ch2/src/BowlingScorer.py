class BowlingScorer:
    def getFramesFromRolls(self, rolls: list) -> list:
        frames = []
        total_score = 0
        score_in_frame = 0
        round_in_frame = 1
        roll_index = 0
        while len(frames) < 10:
            score = rolls[roll_index]
            score_in_frame += score
            if self._is_strike(score, round_in_frame):
                score_in_frame += sum(rolls[roll_index + 1:roll_index + 3])
            elif self._is_spare(score_in_frame, round_in_frame):
                score_in_frame += rolls[roll_index + 1]

            if round_in_frame == 2 or self._is_strike(score, round_in_frame):
                total_score += score_in_frame
                frames.append(total_score)
                round_in_frame = 1
                score_in_frame = 0
            else:
                round_in_frame = 2
            roll_index += 1
        return frames


    def _is_strike(self, currentScore, frameRound):
        return currentScore == 10 and frameRound == 1


    def _is_spare(self, frameScore, frameRound):
        return frameRound == 2 and frameScore == 10
